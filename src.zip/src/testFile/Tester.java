package testFile;

import projTest.*;

public class Tester {

	public static void main(String[] args) {

		RCMView rcmView = new RCMView();
		rcmView.setVisible(true);
		
		RMOSView rmosView = new RMOSView();
		rmosView.setVisible(true);
		
	}

}
